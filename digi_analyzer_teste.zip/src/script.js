const digimons = [
    {
        nome: "Agumon",
        id: "#001",
        imagem: "https://digimon-api.com/images/digimon/agumon.jpg",
        descricao: "Um Digimon réptil com aparência semelhante a um pequeno dinossauro. É conhecido por sua coragem e por seus ataques de fogo.",
        tipo: "Réptil",
        areas: "Ilha File",
        nivel: "Novato",
        habilidade1: "Pepper Breath",
        descHabilidade1: "Lança uma poderosa rajada de fogo pela boca.",
        habilidade2: "Claw Attack",
        descHabilidade2: "Ataque realizado utilizando suas garras."
    },
    {
        nome: "Gabumon",
        id: "#002",
        imagem: "https://digimon-api.com/images/digimon/gabumon.jpg",
        descricao: "Um Digimon réptil tímido que usa uma pele feita de dados de Garurumon. Apesar de reservado, é muito leal.",
        tipo: "Réptil",
        areas: "Montanha",
        nivel: "Novato",
        habilidade1: "Blue Blaster",
        descHabilidade1: "Dispara uma rajada congelante contra o adversário.",
        habilidade2: "Horn Attack",
        descHabilidade2: "Usa seu chifre para realizar um ataque direto."
    },
    {
        nome: "Patamon",
        id: "#003",
        imagem: "https://digimon-api.com/images/digimon/patamon.jpg",
        descricao: "Um pequeno Digimon mamífero conhecido por suas grandes orelhas, que também utiliza para voar.",
        tipo: "Mamífero",
        areas: "Ilha File",
        nivel: "Novato",
        habilidade1: "Boom Bubble",
        descHabilidade1: "Lança uma bolha de ar contra o inimigo.",
        habilidade2: "Air Shot",
        descHabilidade2: "Ataca utilizando uma poderosa rajada de ar."
    },
    {
        nome: "Tentomon",
        id: "#004",
        imagem: "https://digimon-api.com/images/digimon/tentomon.jpg",
        descricao: "Um Digimon inseto inteligente e curioso. É capaz de utilizar eletricidade em seus ataques.",
        tipo: "Inseto",
        areas: "Floresta",
        nivel: "Novato",
        habilidade1: "Super Shocker",
        descHabilidade1: "Utiliza eletricidade para atacar seus adversários.",
        habilidade2: "Electro Shocker",
        descHabilidade2: "Libera uma descarga elétrica poderosa."
    }
];

let atual = 0;

const inicio = document.getElementById("inicio");
const resultado = document.getElementById("resultado");
const campoPesquisa = document.getElementById("campoPesquisa");
const btnPesquisar = document.getElementById("btnPesquisar");
const btnVoltar = document.getElementById("btnVoltar");
const btnAnterior = document.getElementById("btnAnterior");
const btnProximo = document.getElementById("btnProximo");
const mensagemErro = document.getElementById("mensagemErro");

function mostrarDigimon() {
    const digimon = digimons[atual];

    document.getElementById("imagemDigimon").src = digimon.imagem;
    document.getElementById("imagemDigimon").alt = "Imagem do " + digimon.nome;

    document.getElementById("idDigimon").textContent = "ID: " + digimon.id;
    document.getElementById("nomeDigimon").textContent = digimon.nome;
    document.getElementById("descricaoDigimon").textContent = digimon.descricao;
    document.getElementById("tipoDigimon").textContent = digimon.tipo;
    document.getElementById("areasDigimon").textContent = digimon.areas;
    document.getElementById("nivelDigimon").textContent = digimon.nivel;

    document.getElementById("habilidade1").textContent = digimon.habilidade1;
    document.getElementById("descHabilidade1").textContent = digimon.descHabilidade1;

    document.getElementById("habilidade2").textContent = digimon.habilidade2;
    document.getElementById("descHabilidade2").textContent = digimon.descHabilidade2;

    document.getElementById("contador").textContent =
        String(atual + 1).padStart(2, "0") + " / " +
        String(digimons.length).padStart(2, "0");
}

function abrirResultado() {
    inicio.style.display = "none";
    resultado.style.display = "block";
    mostrarDigimon();
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function pesquisarDigimon() {
    const busca = campoPesquisa.value.trim().toLowerCase();

    if (busca === "") {
        mensagemErro.textContent = "Digite o nome de um Digimon.";
        return;
    }

    const encontrado = digimons.find(
        digimon => digimon.nome.toLowerCase() === busca
    );

    if (!encontrado) {
        mensagemErro.textContent =
            "Digimon não encontrado. Tente Agumon, Gabumon, Patamon ou Tentomon.";
        return;
    }

    atual = digimons.indexOf(encontrado);
    mensagemErro.textContent = "";
    abrirResultado();
}

btnPesquisar.addEventListener("click", pesquisarDigimon);

campoPesquisa.addEventListener("keydown", function (evento) {
    if (evento.key === "Enter") {
        pesquisarDigimon();
    }
});

btnProximo.addEventListener("click", function () {
    atual++;

    if (atual >= digimons.length) {
        atual = 0;
    }

    mostrarDigimon();
});

btnAnterior.addEventListener("click", function () {
    atual--;

    if (atual < 0) {
        atual = digimons.length - 1;
    }

    mostrarDigimon();
});

btnVoltar.addEventListener("click", function () {
    resultado.style.display = "none";
    inicio.style.display = "block";
    campoPesquisa.value = "";
    mensagemErro.textContent = "";
});
